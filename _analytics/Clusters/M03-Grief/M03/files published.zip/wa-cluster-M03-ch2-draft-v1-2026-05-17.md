# Grief, Sorrow and Mourning — Chapter 2 draft
## The characteristics in this study

**Cluster:** M03 (Grief)
**Chapter:** 2 — The characteristics in this study
**Style and method:** wa-sessionc-cluster-style-method-v1_1-20260512.md
**Chapter instruction:** wa-sessionc-cluster-ch2-instruction-v1_0-20260512.md
**Generated:** 2026-05-17
**Draft:** wa-cluster-M03-ch2-draft-v1-2026-05-17.md
**Previous output:** wa-cluster-M03-ch1-draft-v1-2026-05-17.md

---

## Cross-chapter consistency: characteristics in this study

- **Weeping and Tears** — This sub-group names the somatic and visible expression of grief through weeping and tears.
- **Mourning and Lamentation** — This sub-group names the act and condition of mourning — the outward form that grief takes in its social, ritual, communal, and personal expression.
- **Boundary Terms** — Structural holding sub-group for the 28 terms designated as BOUNDARY at Phase 3.
- **Sorrow and Inner Grief** — This sub-group names grief as a settled inner emotional condition — the state of the person who is sorrowful, grieved, or weighted with sorrow in the soul and heart.
- **Anguish and Distress** — This sub-group names grief's most intense, overwhelming form — anguish as a pressing, constricting, crushing inner state.
- **Groaning and Sighing** — This sub-group names the involuntary or deliberate vocal and bodily expression of grief through groaning, sighing, and travail-like utterance.
- **Pain and Inner Ache** — This sub-group names grief at the level of pain — the ache, wound, and soreness of the inner person.
- **Bitterness of Soul** — This sub-group names the specific inner quality of bitterness that arises from grief, suffering, loss, and divine dealings — the soul's experience of something that has become harsh, sharp, and without sweetness.

---

## 2. The characteristics in this study

The Bible's vocabulary for grief, sorrow, and mourning organises into seven distinct characteristics — each a different way the inner person experiences, expresses, or is shaped by the weight of loss — together with a set of related supporting terms. Taken together they map the full range of what it means, from the inside, to be a creature who grieves.

---

### 2.1 Weeping and Tears

Weeping and tears is the most visible and immediate face of grief — the moment when sorrow in the inner person breaks through the body's surface and becomes audible, visible, and physically present. It names the act of weeping itself, the sound it makes, and the physical substance of tears. Scripture presents weeping as something that can no longer be contained: the grief presses from within until it overflows outward.

The range of the evidence is wide. Weeping accompanies bereavement, exile, penitence, and prophetic anguish. It can be communal — entire peoples weeping together — or intensely private. It can be irresistible: when Joseph reveals himself to his brothers, his weeping is so uncontainable that it carries through the whole household. As Gen 45:2 records: "And he wept aloud, so that the Egyptians heard it, and the household of Pharaoh heard it." Equally, weeping can be bounded and purposeful: when the days of mourning for Jacob were concluded, the period had a shape, a beginning and an end, after which life resumed — "And when the days of weeping for him were past, Joseph spoke to the household of Pharaoh" (Gen 50:4).

Scripture also shows tears as having weight before God. Hezekiah's tears are seen and answered; Josiah's weeping before the Lord moves God to hear him. Tears are not merely emotion — they are the body's testimony to what is happening in the inner person, and God attends to them.

What distinguishes weeping and tears from the other characteristics in this study is its primary register: it is the somatic and visible expression of grief, rather than grief as inner condition, structured practice, or vocal utterance. Tears are what grief looks like from the outside. The inner condition of sorrow belongs to a different characteristic entirely; weeping is how that condition makes itself known.

---

### 2.2 Mourning and Lamentation

Mourning and lamentation is grief given public, structured form — the act of mourning rather than the inner state of sorrow. Where weeping is the body's immediate overflow, mourning is the organised, socially recognised practice through which grief is held, expressed, and shared. It encompasses mourning periods with defined duration, mourning garments such as sackcloth, lament cries voiced in public spaces, and the communal wailing that gives individual grief a shared social shape.

The biblical mourning vocabulary is deliberately outward and enacted. Abraham goes in to mourn for Sarah — a deliberate, willed act directed toward his deceased wife: "And Abraham went in to mourn for Sarah and to weep for her" (Gen 23:2). Jacob's mourning after the believed loss of Joseph is prolonged and embodied: "Then Jacob tore his garments and put sackcloth on his loins and mourned for his son many days" (Gen 37:34). Both show mourning as something the person chooses to do in response to grief — not merely something grief does to them.

Mourning in Scripture is also commanded, withheld, and reversed. God calls entire communities to mourn as an act of moral response to national catastrophe. He forbids mourning when the relational context has been broken. And he transforms it: Psa 30:11 declares "You have turned for me my mourning into dancing" — a reversal that only divine action can accomplish. The Beatitudes frame mourning as the inner condition that receives divine comfort (Mat 5:4), and James commands it where levity is morally inappropriate (Jam 4:9).

What distinguishes mourning and lamentation from weeping and tears is its structured, social character. Weeping is the immediate bodily expression of inner grief; mourning is the organised, communal, and often ritually shaped act through which that grief is sustained and given form over time.

---

### 2.3 Supporting characteristics

A substantial group of terms gathered in the verse evidence for this study are held as supporting rather than primary characteristics. These twenty-eight terms sit at the edges of the grief vocabulary — touching it but not fully belonging to it, or belonging partly to other areas of the inner life as well.

The range is wide. Some terms belong primarily to the vocabulary of weakness, pressure, or affliction — the crushing weight of suffering rather than grief specifically (terms such as *thlibō*, pressed or hemmed in, and *stenochōreō*, confined by distress). Others belong to a torment or judgment register, naming the suffering of the condemned rather than the grief of the bereaved. Several terms cross into neighbouring areas of inner life: the complaint-and-meditation vocabulary (*si.ach*) touches both lament and reflective inner speech; the bitterness-and-provocation vocabulary (*ma.rar*) connects both to grief's sharpness and to the anger vocabulary Scripture addresses separately. The birth-pang and toil vocabulary stands at the intersection of grief, bodily suffering, and the consequences of the fall. Gen 3:16 provides the foundational text for two of these terms: "I will surely multiply your pain in childbearing; in pain you shall bring forth children." The verse speaks twice — once naming the pain of labour (*e.tsev*) as something divinely multiplied, and once naming the toil and anguish (*its.tsa.von*) bound up with bringing forth life after the fall. Both terms carry an inner weight that touches the grief vocabulary, yet neither is grief alone.

These terms appear in the verse evidence of the study and inform the picture of grief that emerges from it. However, they are not analysed at full depth in the chapters that follow. They occupy the edges of the grief vocabulary — present, relevant, but awaiting decisions about where, precisely, they belong in the broader landscape of the inner life.

---

### 2.4 Sorrow and Inner Grief

Sorrow and inner grief names the interior condition of the grieving person — not what grief looks like from outside, and not the acts through which grief is expressed, but what it is to carry grief within. This is grief as a weight lodged in the heart, a condition of the soul that occupies the inner person and will not easily be discharged.

The vocabulary consistently locates sorrow directly in the soul and heart. Deuteronomy captures the full anatomy of this depletion in its description of exile: "the Lord will give you there a trembling heart and failing eyes and a languishing soul" (Deu 28:65) — a picture of sorrow as a condition that pervades the whole inner and outer person, giving the soul nowhere to rest. The psalmist in Psa 13:2 gives the characteristic its clearest shape: "How long must I take counsel in my soul and have sorrow in my heart all the day?" The sorrow is not a passing mood — it sits in the heart all day long, an inward burden sustained over time. At its most intense, grief of this kind does not merely weigh on the soul but dissolves it: "My soul melts away for sorrow; strengthen me according to your word!" (Psa 119:28). In Gethsemane, Jesus names this condition in himself at its absolute depth: "My soul is very sorrowful, even to death" (Mat 26:38).

Sorrow and inner grief is also morally significant. Jesus is grieved by the Pharisees' hardness of heart alongside his anger (Mar 3:5) — grief here is a compassionate inner response to moral failure in others. And godly grief, as 2 Corinthians 7:11 shows, is generative: it produces earnestness, indignation, fear, and zeal — the whole reforming energy of repentance.

What distinguishes this characteristic from the others is its location and nature: it is the inner condition itself, not its outward expression through tears or groaning, and not its social form in mourning. Sorrow and inner grief is what the person is carrying before it overflows — or even when it never overflows at all.

---

### 2.5 Anguish and Distress

Anguish and distress names the most acute and overwhelming form of grief — grief at its most pressing, when suffering becomes so intense that the inner person is seized, constricted, and driven to cry out. Where sorrow and inner grief is the sustained weight of sadness lodged in the heart, anguish is the experience of being crushed by it — a force that presses in on the inner being and will not release its grip.

The biblical vocabulary for anguish is large and dominated by the distress that drives prayer. Job 15:24 personifies distress at its most terrifying: "distress and anguish terrify him; they prevail against him, like a king ready for battle" — an overwhelming force that does not merely press but defeats. In Psa 18:6 the pattern shifts to its redemptive form: "In my distress I called upon the Lord; to my God I cried for help. From his temple he heard my voice, and my cry to him reached his ears." Distress arrives, the person cries, God hears and answers. This sequence runs through dozens of verses in the Psalms and prophets — anguish is the inner crisis that propels the person toward God. Job reaches even deeper, locating anguish at spirit level: "I will speak in the anguish of my spirit; I will complain in the bitterness of my soul" (Job 7:11). Paul, writing to the Romans, names his anguish as heart-located and unceasing: "I have great sorrow and unceasing anguish in my heart" (Rom 9:2) — a sustained inner suffering over Israel's lostness that neither resolves nor relents.

What distinguishes anguish and distress from sorrow and inner grief is intensity and mode. Sorrow is the condition of carrying grief; anguish is the experience of being overwhelmed by it. Anguish presses, grips, seizes — it is grief at the point where the inner person can no longer hold it in silence but must cry out.

---

### 2.6 Groaning and Sighing

Groaning and sighing names the vocal and bodily utterance through which grief finds its most elemental expression — the involuntary sound that escapes when the inner person is under pressure too great for silence. It is neither the structured practice of mourning nor the visible overflow of tears; it is the raw, often wordless cry of a suffering inner life reaching toward God or toward others.

Scripture presents groaning as heard and responded to. When Israel groans under slavery, the cry is covenantally significant: "The people of Israel groaned because of their slavery and cried out for help. Their cry for rescue from slavery came up to God" (Exo 2:23). The following verse records the divine response: "And God heard their groaning, and God remembered his covenant with Abraham, with Isaac, and with Jacob" (Exo 2:24). The groan is not merely physiological — it rises and is received. The Psalms locate groaning in the heart: "I am feeble and crushed; I groan because of the tumult of my heart" (Psa 38:8). The whole creation groans together in the labour-pain of not-yet-redeemed existence (Rom 8:22). And the Spirit himself groans within the believer, interceding where human words fail: "the Spirit himself intercedes for us with groanings too deep for words" (Rom 8:26).

Job gives the sustained-condition form of this characteristic its starkest statement: "For my sighing comes instead of my bread, and my groanings are poured out like water" (Job 3:24). Sighing has replaced the basic sustenance of life — it is no longer an episode of grief but its continuous condition.

What distinguishes groaning and sighing from weeping and tears is that it is primarily vocal and respiratory rather than visible and somatic. Where tears are the body's surface expression of grief, groaning is its deep inner voice.

---

### 2.7 Pain and Inner Ache

Pain and inner ache names grief at the level of felt suffering — not the weight of sorrow, not the acuity of anguish, but the phenomenological quality of what grief is like from within. It is grief experienced as wound, ache, and persistent soreness — something that hurts.

The characteristic is established most memorably in the servant of Isaiah 53: "He was despised and rejected by men, a man of sorrows, and acquainted with grief" (Isa 53:3). Pain is not an episode in the servant's life but the defining feature of his identity — he is the man of sorrows. The king in Daniel 6, approaching the lion's den, gives the characteristic its most personal form: "He cried out in a tone of anguish" (Dan 6:20), the anxious pain of one who fears he has lost a faithful servant. Jeremiah gives it its most desolate form — unceasing pain that has become a wound that refuses to heal, and that calls God's own faithfulness into question: "Why is my pain unceasing, my wound incurable, refusing to be healed? Will you be to me like a deceitful brook, like waters that fail?" (Jer 15:18).

The birth-pangs vocabulary belongs here as well — the seizure of acute involuntary pain that comes upon people in catastrophe, described in Isa 13:8 as pangs and agony that grip and produce visible outer symptoms of inner anguish.

What distinguishes pain and inner ache from sorrow and inner grief is texture and phenomenology. Sorrow is the weight of sadness; pain is what that sadness feels like as an experience — the hurt, the ache, the wound that will not close.

---

### 2.8 Bitterness of Soul

Bitterness of soul names the specific quality that grief acquires when it becomes sharp, harsh, and without sweetness — the taste of suffering at its most unrelieved. It is grief that has curdled into a pervasive inner colouring, a state of soul that is no longer merely sorrowful but has taken on a quality of harshness the person cannot escape.

Scripture presents bitterness as something that can be inflicted by circumstances, by God, and by other people. Esau's foreign wives made life itself bitter for Isaac and Rebekah: "and they made life bitter for Isaac and Rebekah" (Gen 26:35). Job describes God's dealings in terms of total saturation: "he will not let me get my breath, but fills me with bitterness" (Job 9:18) — an overwhelming inner quality imposed from without that leaves no room for relief. Lamentations 3:15 describes the same totality from the other direction: "He has filled me with bitterness; he has sated me with wormwood." Proverbs 14:10 gives bitterness its most intimate shape: "The heart knows its own bitterness, and no stranger shares its joy" — a private inner state sealed within the self, inaccessible to others.

Bitterness of soul in this study is grief-bitterness, not anger-bitterness. The anger vocabulary of harshness and hostility belongs to a separate part of Scripture's account of the inner life; what is named here is the quality that prolonged grief, loss, suffering, and divine dealings can impart to the inner life — the soul's experience of something that has turned harsh and without sweetness. The relationship between these two registers — bitterness as an experience that happens to the person and bitterness as a state the person can settle into — is itself part of what the evidence invites the reader to examine.

---

**Evidence: per-characteristic descriptions and key verses from the analytical record**

<!-- EVIDENCE: Ch2 — §2.1 Weeping and Tears -->

**Sub-group description (from analytical record):**

> This sub-group names the somatic and visible expression of grief through weeping and tears. The meanings consistently show weeping as an inner state that overflows outward into the body — tears that drench the bed, exhaust the eyes, flow continuously on the face, or are so abundant the prophet longs for a fountain to sustain them. Tears function as recognised evidence of inner grief: God sees them, hears the sound of them, and records them. Weeping is communal as well as personal, penitential as well as bereavement-driven. The unifying characteristic is that these terms specifically name the act, sound, or substance of weeping and tears as the primary inner-grief indicator.

**Key verses for this characteristic:**

**Gen 45:2** (H1065 be.khi) [M03-A-VCG-01]
> Gen 45:2 And he wept aloud , so that the Egyptians heard it, and the household of Pharaoh heard it.
_Meaning of the term here:_ Joseph's weeping at his self-revelation is so loud it is heard throughout Pharaoh's household; the weeping is an uncontainable outpouring of pent-up emotion — grief, relief, and joy — breaking through publicly.

**Gen 50:4** (H1068 be.khit) [M03-A-VCG-01]
> Gen 50:4 And when the days of weeping for him were past , Joseph spoke to the household of Pharaoh , saying , " If now I have found favor in your eyes , please speak in the ears of Pharaoh , saying ,
_Meaning of the term here:_ The days of weeping for Jacob are described as a defined, concluded period; this frames grief as a bounded communal experience with an end point, after which practical action resumes.

**2Sa 18:33** (H1058 ba.khah) [M03-A-VCG-01]
> 2Sa 18:33 And the king was deeply moved and went up to the chamber over the gate and wept . And as he went , he said , "O my son Absalom , my son , my son Absalom ! Would I had died instead of you, O Absalom , my son , my son !"
_Meaning of the term here:_ David's weeping for Absalom is the most raw parental grief in the narrative—he would rather have died himself; grief here is total, overwhelming, and longing for the lost child.

**2Ki 20:5** (H1832 dim.ah) [M03-A-VCG-02]
> 2Ki 20:5 "Turn back , and say to Hezekiah the leader of my people , Thus says the Lord , the God of David your father : I have heard your prayer ; I have seen your tears . Behold , I will heal you. On the third day you shall go up to the house of the Lord ,
_Meaning of the term here:_ God declares he has seen Hezekiah's tears, showing that the inner grief expressed outwardly moved God to respond with healing, so the tears function as a petition heard by the divine.

**2Ki 22:19** (H1058 ba.khah) [M03-A-VCG-02]
> 2Ki 22:19 because your heart was penitent , and you humbled yourself before the Lord , when you heard how I spoke against this place and against its inhabitants , that they should become a desolation and a curse , and you have torn your clothes and wept before me , I also have heard you, declares the Lord .
_Meaning of the term here:_ Josiah's weeping before the Lord is presented as the outward expression of a penitent, humbled heart responding to divine judgment, and it moves God to hear him.

**Ezr 10:1** (H1059 be.kheh) [M03-A-VCG-02]
> Ezr 10:1 While Ezra prayed and made confession , weeping and casting himself down before the house of God , a very great assembly of men , women , and children , gathered to him out of Israel , for the people wept bitterly .
_Meaning of the term here:_ The people's weeping is described as bitter, intensifying the inner quality of their grief over Israel's unfaithfulness — it is not mild sorrow but a sharp, deeply felt anguish.

**Mal 2:13** (H0603 a.na.qah) [M03-A-VCG-02]
> Mal 2:13 And this second thing you do . You cover the Lord's altar with tears , with weeping and groaning because he no longer regards the offering or accepts it with favor from your hand .
_Meaning of the term here:_ Groaning here accompanies weeping and tears brought to the altar, expressing deep emotional distress over God's rejection of the people's offerings—but the grief is outward performance rather than evidence of genuine inner repentance.

**Psa 137:1** (H1058 ba.khah) [M03-A-VCG-03]
> Psa 137:1 By the waters of Babylon , there we sat down and wept , when we remembered Zion .
_Meaning of the term here:_ Weeping is the communal grief of exiles sitting by Babylon's waters as they remember Zion—sorrow is triggered by memory of loss and expressed as collective mourning.

**Jer 9:1** (H1058 ba.khah) [M03-A-VCG-04]
> Jer 9:1 Oh that my head were waters , and my eyes a fountain of tears , that I might weep day and night for the slain of the daughter of my people !
_Meaning of the term here:_ The prophet longs for a limitless capacity to weep—head as waters, eyes as a fountain—expressing that grief over his people's destruction demands more tears than the body can produce, a desire for inexhaustible inner sorrow.

**Jer 13:17** (H1830 da.ma) [M03-A-VCG-04]
> Jer 13:17 But if you will not listen , my soul will weep in secret for your pride ; my eyes will weep bitterly and run down with tears , because the Lord's flock has been taken captive .
_Meaning of the term here:_ The eyes weep bitterly and run down with tears; this weeping is the visible, intensified overflow of the soul's hidden grief, provoked by the Lord's flock being taken captive.

**Mat 2:18** (G2805 klauthmos) [M03-A-VCG-05]
> Mat 2:18 "A voice was heard in Ramah , weeping and loud lamentation , Rachel weeping for her children ; she refused to be comforted , because they are no more."
_Meaning of the term here:_ Weeping here is the anguished, unconsolable lament of Rachel (representing Israelite mothers) over children killed by Herod—a grief so total that comfort is refused, expressing absolute inner desolation at irreversible loss.

**Rom 12:15** (G2799 klaiō) [M03-A-VCG-05]
> Rom 12:15 Rejoice with those who rejoice , weep with those who weep .
_Meaning of the term here:_ Believers are commanded to weep with those who weep, indicating that entering into another's grief is an act of the will and empathy—sorrow is to be shared as a form of communal love.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.2 Mourning and Lamentation -->

**Sub-group description (from analytical record):**

> This sub-group names the act and condition of mourning — the outward form that grief takes in its social, ritual, communal, and personal expression. The meanings consistently show mourning as the structured or habitual pattern of grief: mourning periods, mourning garments, lament cries, communal wailing. The sub-group includes both personal mourning for the dead and national disaster, and divinely commanded or withheld mourning that marks the God-people relationship. Mourning is what God himself addresses and reverses: the mourner is the target of divine consolation, and mourning is what eschatological joy displaces. The characteristic that unifies this sub-group is mourning understood as the human act and state of grief given outward, socially recognised form.

**Key verses for this characteristic:**

**Gen 23:2** (H5594 sa.phad) [M03-B-VCG-01]
> Gen 23:2 And Sarah died at Kiriath-arba (that is, Hebron ) in the land of Canaan , and Abraham went in to mourn for Sarah and to weep for her .
_Meaning of the term here:_ Abraham goes in deliberately to mourn for Sarah; the mourning is an intentional, relational act of the will directed toward his deceased wife, expressing inner grief through ritual lamentation.

**Gen 37:34** (H0056 a.val) [M03-B-VCG-01]
> Gen 37:34 Then Jacob tore his garments and put sackcloth on his loins and mourned for his son many days .
_Meaning of the term here:_ Jacob tears his garments, puts on sackcloth, and mourns for his son many days; his mourning is prolonged, embodied, and directed entirely at the believed death of Joseph, expressing inconsolable inner grief.

**Gen 37:35** (H0057 a.vel) [M03-B-VCG-01]
> Gen 37:35 All his sons and all his daughters rose up to comfort him, but he refused to be comforted and said , " No , I shall go down to Sheol to my son , mourning ." Thus his father wept for him.
_Meaning of the term here:_ Jacob refuses all comfort and declares he will go down to Sheol mourning; his mourning is a total inner condition he intends to carry to death, resisting any relief from his grief over Joseph.

**Amo 5:16** (H0060 e.vel) [M03-B-VCG-02]
> Amo 5:16 Therefore thus says the Lord , the God of hosts , the Lord : " In all the squares there shall be wailing , and in all the streets they shall say , ' Alas ! Alas !' They shall call the farmers to mourning and to wailing those who are skilled in lamentation ,
_Meaning of the term here:_ Mourning will fill every public space as farmers and lamentation experts are summoned; this signals grief as a communal, unavoidable inner condition brought by divine judgment penetrating all of society.

**Psa 30:11** (H4553 mis.ped) [M03-B-VCG-03]
> Psa 30:11 You have turned for me my mourning into dancing ; you have loosed my sackcloth and clothed me with gladness ,
_Meaning of the term here:_ Mourning is a state God himself transforms—he turns it into dancing and replaces sackcloth with gladness, showing mourning as a deep inner condition that only divine action can reverse.

**Isa 29:2** (H8386 ta.a.niy.yah) [M03-B-VCG-03]
> Isa 29:2 Yet I will distress Ariel , and there shall be moaning and lamentation , and she shall be to me like an Ariel .
_Meaning of the term here:_ Mourning here is a state of lamentation God himself will bring upon Ariel; the distress will produce moaning and lamentation, turning the city into a site of grief rather than celebration.

**Jer 16:5** (H4798 mar.ze.ach) [M03-B-VCG-03]
> Jer 16:5 "For thus says the Lord : Do not enter the house of mourning , or go to lament or grieve for them, for I have taken away my peace from this people , my steadfast love and mercy , declares the Lord .
_Meaning of the term here:_ The house of mourning is a communal space of shared grief; God forbids entering it because he has withdrawn his peace, love, and mercy from the people, making their mourning rites meaningless.

**Mat 5:4** (G3996 pen.the.o) [M03-B-VCG-04]
> Mat 5:4 " Blessed are those who mourn , for they shall be comforted .
_Meaning of the term here:_ Mourning here is the inner condition of those who grieve—whether over sin, loss, or the brokenness of the world—and Jesus declares it blessed because it will be met with divine comfort, linking inner sorrow to future consolation.

**2Cor 7:7** (G3602 odurmos) [M03-B-VCG-04]
> 2Cor 7:7 and not only by his coming but also by the comfort with which he was comforted by you , as he told us of your longing , your mourning , your zeal for me , so that I rejoiced still more .
_Meaning of the term here:_ The Corinthians' mourning—reported to Paul through Titus—is a genuine inner sorrow that paradoxically produces Paul's joy; their grief over the situation becomes a sign of repentance and relational restoration.

**Jam 4:9** (G3997 penthos) [M03-B-VCG-04]
> Jam 4:9 Be wretched and mourn and weep . Let your laughter be turned to mourning and your joy to gloom .
_Meaning of the term here:_ Grief (penthos) is commanded as the appropriate displacement of joy — it is the inward affect that should replace levity when one recognizes sin, signaling the heart's proper orientation toward repentance.

**Rev 1:7** (G2875 koptō) [M03-B-VCG-04]
> Rev 1:7 Behold , he is coming with the clouds , and every eye will see him , even those who pierced him , and all tribes of the earth will wail on account of him . Even so . Amen .
_Meaning of the term here:_ All tribes of the earth will wail when they see Christ coming — the mourning is a future corporate inner response of anguish and grief upon beholding the one they pierced, driven by recognition and dread.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.3 Boundary Terms -->

**Sub-group description (from analytical record):**

> Structural holding sub-group for the 28 terms designated as BOUNDARY at Phase 3. These terms are held pending researcher decision at Phase 12. Analytical questions include: terms whose register may align to M24-Weakness (affliction/pressure: thlibō, ponos, stenochōreō, sumpaschō, mu.a.qah, ma.tsoq); terms in the torment/judgment register (basanizō ×2, basanos, ma.a.tse.vah); terms with corpus spanning M03 and another cluster (ma.rar — M03 grief-bitterness + M02 anger/provocation; si.ach — M03 complaint-lament + M17 meditation); terms in the labour-pain or faintness or toil-suffering register (cha.val, dav.va, cha.lah, e.tsev, o.tsev, its.tsa.von); terms with wide or mixed semantic corpus (a.mal, che.vel-M cord-register, ra.ah-harm); and terms with insufficient corpus for a firm verdict (ne.dud, tsoq, tsu.qah, qe.pha.dah, pid, tsir). No characteristic-bearing analysis is conducted at Phase 5 for these terms.

**Key verses for this characteristic:**

**Gen 3:16** (H6089A e.tsev) [M03-BOUNDARY-VCG-01]
> Gen 3:16 To the woman he said , "I will surely multiply your pain in childbearing ; in pain you shall bring forth children . Your desire shall be for your husband , and he shall rule over you ."
_Meaning of the term here:_ The woman's pain in childbearing is divinely multiplied as a consequence of the fall; it is a bodily and inner anguish imposed on her in the most intimate act of creation, linking suffering to her core vocation.

**Gen 3:16** (H6093 its.tsa.von) [M03-BOUNDARY-VCG-01]
> Gen 3:16 To the woman he said , "I will surely multiply your pain in childbearing ; in pain you shall bring forth children . Your desire shall be for your husband , and he shall rule over you ."
_Meaning of the term here:_ The woman's toil is expressed as multiplied pain in childbearing, a curse-laden inner suffering tied to the bodily experience of bringing forth life after the fall.

**Gen 41:51** (H5999 a.mal) [M03-BOUNDARY-VCG-01]
> Gen 41:51 Joseph called the name of the firstborn Manasseh . " For ," he said, " God has made me forget all my hardship and all my father's house ."
_Meaning of the term here:_ Joseph names his son Manasseh because God made him forget all his hardship; the trouble was a deep inner burden of suffering and estrangement that God's blessing caused him to release from memory.

**Gen 49:23** (H4843 ma.rar) [M03-BOUNDARY-VCG-01]
> Gen 49:23 The archers bitterly attacked him , shot at him , and harassed him severely ,
_Meaning of the term here:_ The archers' bitter attacking of Joseph is the outward violent expression of provocation aimed at him — the term names the hostile, embittering pressure exerted against a person by adversaries.

**Num 11:15** (H7451C ra.ah) [M03-BOUNDARY-VCG-01]
> Num 11:15 If you will treat me like this, kill me at once , if I find favor in your sight , that I may not see my wretchedness ."
_Meaning of the term here:_ Moses's inner distress is so crushing that he would rather die than continue to witness or endure it; the harm he names is his own wretchedness, a burden he can no longer bear.

**Deu 28:53** (H4689 ma.tsoq) [M03-BOUNDARY-VCG-01]
> Deu 28:53 And you shall eat the fruit of your womb , the flesh of your sons and daughters , whom the Lord your God has given you, in the siege and in the distress with which your enemies shall distress you.
_Meaning of the term here:_ Distress here is an extreme siege condition imposed by enemies that so crushes the inner and outer person that it drives people to cannibalism of their own children to survive.

**1Sa 22:8** (H2470I cha.lah) [M03-BOUNDARY-VCG-01]
> 1Sa 22:8 that all of you have conspired against me? No one discloses to me when my son makes a covenant with the son of Jesse . None of you is sorry for me or discloses to me that my son has stirred up my servant against me, to lie in wait , as at this day ."
_Meaning of the term here:_ Being grieved here is the felt pain of being pitied or shown sympathy; Saul laments that none of his servants feels sorry for him, revealing his inner loneliness amid perceived betrayal.

**2Sa 22:6** (H2256M che.vel) [M03-BOUNDARY-VCG-01]
> 2Sa 22:6 the cords of Sheol entangled me; the snares of death confronted me.
_Meaning of the term here:_ The 'cords' of Sheol are imagery of death's grip entangling the inner person; pain here is the anguish of being caught in mortal danger with no human escape.

**1Ch 4:9** (H6090A o.tsev) [M03-BOUNDARY-VCG-01]
> 1Ch 4:9 Jabez was more honorable than his brothers ; and his mother called his name Jabez , saying , " Because I bore him in pain ."
_Meaning of the term here:_ The pain here is the mother's birth-pain that became the defining inner-experience memorialized in her son's name, marking his very origin with suffering.

**Job 7:4** (H5076 ne.dud) [M03-BOUNDARY-VCG-01]
> Job 7:4 When I lie down I say , ' When shall I arise ?' But the night is long , and I toss and turn till the dawn .
_Meaning of the term here:_ Job's sleepless tossing through the long night expresses inner distress and agitation—his suffering keeps his body and mind from rest until dawn.

**Job 10:1** (H7879 si.ach) [M03-BOUNDARY-VCG-01]
> Job 10:1 "I loathe my life ; I will give free utterance to my complaint ; I will speak in the bitterness of my soul .
_Meaning of the term here:_ Job's complaint pours out freely as vocal expression of inner anguish—it is spoken 'in the bitterness of my soul,' locating it in the soul and driven by loathing of life itself.

**Job 12:5** (H6365 pid) [M03-BOUNDARY-VCG-01]
> Job 12:5 In the thought of one who is at ease there is contempt for misfortune ; it is ready for those whose feet slip .
_Meaning of the term here:_ Disaster is treated with contempt by the comfortable person—their ease of mind blinds them to the reality of misfortune, showing that inner security produces indifference to another's ruin.

**Psa 66:11** (H4157 mu.a.qah) [M03-BOUNDARY-VCG-01]
> Psa 66:11 You brought us into the net ; you laid a crushing burden on our backs ;
_Meaning of the term here:_ Distress is imposed by God himself — a crushing burden laid on the people's backs like a net — presenting affliction as a divinely permitted oppression bearing down on the community.

**Pro 1:27** (H6695B tsu.qah) [M03-BOUNDARY-VCG-01]
> Pro 1:27 when terror strikes you like a storm and your calamity comes like a whirlwind , when distress and anguish come upon you.
_Meaning of the term here:_ Anguish comes suddenly upon the one who rejected wisdom, crashing in like a storm—it is an overwhelming inner terror that wisdom's rejection leaves one defenseless against.

**Isa 1:5** (H1742 dav.va) [M03-BOUNDARY-VCG-01]
> Isa 1:5 Why will you still be struck down ? Why will you continue to rebel ? The whole head is sick , and the whole heart faint .
_Meaning of the term here:_ The whole heart is faint—an exhausted, weakened inner condition caused by repeated rebellion and divine chastisement, leaving the inner person depleted and without strength.

**Isa 50:11** (H4620 ma.a.tse.vah) [M03-BOUNDARY-VCG-01]
> Isa 50:11 Behold , all you who kindle a fire , who equip yourselves with burning torches ! Walk by the light of your fire , and by the torches that you have kindled ! This you have from my hand : you shall lie down in torment .
_Meaning of the term here:_ Torment is the divinely appointed end for those who walk by self-kindled fire rather than trusting God; lying down in torment is the consequence imposed from God's hand on the self-reliant.

**Eze 7:25** (H7089 qe.pha.dah) [M03-BOUNDARY-VCG-01]
> Eze 7:25 When anguish comes , they will seek peace , but there shall be none .
_Meaning of the term here:_ Anguish drives people to seek peace, revealing it as an inner condition of dread and terror so severe that it produces desperate searching—yet peace will not be found to relieve it.

**Dan 9:25** (H6695A tsoq) [M03-BOUNDARY-VCG-01]
> Dan 9:25 Know therefore and understand that from the going out of the word to restore and build Jerusalem to the coming of an anointed one , a prince , there shall be seven weeks . And for sixty-two weeks it shall be built again with squares and moat , but in a troubled time .
_Meaning of the term here:_ Distress characterizes the troubled time in which Jerusalem will be rebuilt; the word marks the historical period as one of oppressive external pressure bearing inwardly on the people.

**Mat 8:29** (G0928G basanizō) [M03-BOUNDARY-VCG-01]
> Mat 8:29 And behold , they cried out , " What have you to do with us , O Son of God ? Have you come here to torment us before the time ?"
_Meaning of the term here:_ The demons dread being tormented by Jesus before the appointed time, indicating that tormenting here refers to a severe, feared punishment they know awaits them, experienced as deeply threatening to their existence.

**Mat 9:36** (G4660 skullō) [M03-BOUNDARY-VCG-01]
> Mat 9:36 When he saw the crowds , he had compassion for them , because they were harassed and helpless , like sheep without a shepherd .
_Meaning of the term here:_ The crowds are harassed and helpless, their troubled state evoking compassion in Jesus—the trouble here is an external affliction that has left them inwardly worn down and without direction, like sheep without a shepherd.

**Mar 3:9** (G2346 thlibō) [M03-BOUNDARY-VCG-01]
> Mar 3:9 And he told his disciples to have a boat ready for him because of the crowd , lest they crush him ,
_Meaning of the term here:_ The pressing here is purely physical—the crowd threatening to crush Jesus—so the inner-being dimension is minimal; the verse shows the external pressure that mirrors the inward constriction this term conveys elsewhere.

**Luk 16:23** (G0931 basanos) [M03-BOUNDARY-VCG-01]
> Luk 16:23 and in Hades , being in torment , he lifted up his eyes and saw Abraham far off and Lazarus at his side .
_Meaning of the term here:_ The rich man is in torment in Hades—a state of severe suffering in the afterlife that he is consciously experiencing, able to see and long for relief, making torment here a fully felt inner and bodily anguish of the condemned.

**Rom 8:17** (G4841 sumpaschō) [M03-BOUNDARY-VCG-01]
> Rom 8:17 and if children , then heirs — heirs of God and fellow heirs with Christ , provided we suffer with him in order that we may also be glorified with him.
_Meaning of the term here:_ Suffering with Christ is presented as the condition of sharing in his glory; the inner willingness to co-suffer with him is the pathway through which the believer participates in both his pain and his vindication.

**2Cor 4:8** (G4729 stenochōreō) [M03-BOUNDARY-VCG-01]
> 2Cor 4:8 We are afflicted in every way , but not crushed ; perplexed , but not driven to despair ;
_Meaning of the term here:_ Though pressed and perplexed, Paul is not driven to despair—the inner being is hemmed in but retains space; the contrast between being pressed upon and not being crushed shows the inner person's God-given resilience.

**Rev 12:2** (G0928H basanizō) [M03-BOUNDARY-VCG-01]
> Rev 12:2 She was pregnant and was crying out in birth pains and the agony of giving birth .
_Meaning of the term here:_ The woman cries out in the agony of giving birth — the anguish is intense bodily and inner torment at the moment of travail, depicting a figure in extreme distress straining toward deliverance.

**Rev 16:10** (G4192 ponos) [M03-BOUNDARY-VCG-01]
> Rev 16:10 The fifth angel poured out his bowl on the throne of the beast , and its kingdom was plunged into darkness . People gnawed their tongues in anguish
_Meaning of the term here:_ People gnawed their tongues in anguish under the fifth bowl judgment — the travail/pain is an acute, bodily inner suffering so intense it produces self-harm, signaling extremity of inner distress under divine wrath.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.4 Sorrow and Inner Grief -->

**Sub-group description (from analytical record):**

> This sub-group names grief as a settled inner emotional condition — the state of the person who is sorrowful, grieved, or weighted with sorrow in the soul and heart. The meanings consistently locate grief in the inner person directly: Jesus's soul is very sorrowful, even to death; sorrow is lodged in the heart all day long; grief is so deep the soul melts away. The distinguishing feature is the inner-state character of the grief — the sorrow is felt, located in the heart or soul, and experienced as an inner condition rather than primarily expressed outward. This register includes grief that is morally motivated, grief at relational loss, grief that coexists with joy, and godly grief that produces repentance.

**Key verses for this characteristic:**

**Deu 28:65** (H1671 de.a.von) [M03-C-VCG-01]
> Deu 28:65 And among these nations you shall find no respite , and there shall be no resting place for the sole of your foot , but the Lord will give you there a trembling heart and failing eyes and a languishing soul .
_Meaning of the term here:_ Sorrow here is located in the soul as a languishing, joined to a trembling heart and failing eyes, showing it is a deep inner depletion God gives as punishment among the nations.

**Psa 13:2** (H3015 ya.gon) [M03-C-VCG-01]
> Psa 13:2 How long must I take counsel in my soul and have sorrow in my heart all the day ? How long shall my enemy be exalted over me ?
_Meaning of the term here:_ Sorrow is lodged in the heart all day long—it is a sustained, inward emotional burden that occupies the heart continually, intensified by the sense of being abandoned and overpowered by enemies.

**Psa 119:28** (H8424 tu.gah) [M03-C-VCG-01]
> Psa 119:28 My soul melts away for sorrow ; strengthen me according to your word !
_Meaning of the term here:_ Grief is so deep it causes the soul to melt away—an inner dissolution of the self under sorrow, which only God's word can strengthen and restore.

**Mar 3:5** (G4818 sullupeō) [M03-C-VCG-02]
> Mar 3:5 And he looked around at them with anger , grieved at their hardness of heart , and said to the man , " Stretch out your hand ." He stretched it out , and his hand was restored .
_Meaning of the term here:_ Jesus is grieved simultaneously with his anger at the Pharisees' hardness of heart—the grief is a compassionate inner pain over moral and spiritual stubbornness, showing sorrow as a response to others' willful blindness.

**2Cor 7:11** (G3076 lupeō) [M03-C-VCG-02]
> 2Cor 7:11 For see what earnestness this godly grief has produced in you , but also what eagerness to clear yourselves, what indignation , what fear , what longing , what zeal , what punishment ! At every point you have proved yourselves innocent in the matter .
_Meaning of the term here:_ Godly grief produced earnestness, indignation, fear, and zeal in the Corinthians' inner being; the sorrow became a generative force reshaping their will, conscience, and moral energy.

**Mat 26:38** (G4036 perilupos) [M03-C-VCG-03]
> Mat 26:38 Then he said to them , " My soul is very sorrowful , even to death ; remain here , and watch with me ."
_Meaning of the term here:_ Jesus describes his soul as very sorrowful, even to death—the grief is located explicitly in the soul and reaches such an extreme depth that it threatens life itself, expressing maximum inner anguish in Gethsemane.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.5 Anguish and Distress -->

**Sub-group description (from analytical record):**

> This sub-group names grief's most intense, overwhelming form — anguish as a pressing, constricting, crushing inner state. The meanings consistently show distress as a force that presses in on the inner person, grips the soul and spirit, and drives the sufferer to cry out to God for deliverance. The two largest corpora in the cluster — tsa.rah (62 verses) and tsar (28 verses) — both consistently show distress as the inner-being crisis driving prayer and from which God delivers. The Greek anguish vocabulary supplements this: sunochē (heart-seated anguish), odunaō (anguish at relational loss and afterlife), odunē (heart-located unceasing sorrow). The unifying characteristic is anguish as the most acute and pressing form of inner suffering.

**Key verses for this characteristic:**

**Job 15:24** (H4691 me.tsu.qah) [M03-D-VCG-01]
> Job 15:24 distress and anguish terrify him; they prevail against him, like a king ready for battle .
_Meaning of the term here:_ Distress is personified as an overwhelming force that terrifies and overpowers the wicked man, assaulting him like a battle-ready king—it is an external terror that defeats the inner person.

**Psa 18:6** (H6862B tsar) [M03-D-VCG-01]
> Psa 18:6 In my distress I called upon the Lord ; to my God I cried for help . From his temple he heard my voice , and my cry to him reached his ears .
_Meaning of the term here:_ Distress is the inner crisis that drives the psalmist to cry out to God—it is the prompt for urgent prayer, and God's response from his temple shows that distress is heard and answered.

**Job 7:11** (H6862B tsar) [M03-D-VCG-02]
> Job 7:11 " Therefore I will not restrain my mouth ; I will speak in the anguish of my spirit ; I will complain in the bitterness of my soul .
_Meaning of the term here:_ Job speaks from the anguish of his spirit, locating distress explicitly in his innermost being — the spirit — from which he can no longer restrain his words or hold back complaint.

**Rom 9:2** (G3601 odunē) [M03-D-VCG-02]
> Rom 9:2 that I have great sorrow and unceasing anguish in my heart .
_Meaning of the term here:_ Paul locates his anguish explicitly in the heart, describing it as great and unceasing sorrow over Israel's lostness; the anguish is a sustained, deep-seated inner pain of conscience and love for his people.

**Deu 4:30** (H6862B tsar) [M03-D-VCG-03]
> Deu 4:30 When you are in tribulation , and all these things come upon you in the latter days , you will return to the Lord your God and obey his voice .
_Meaning of the term here:_ Distress here functions as a catalyst for repentance; when tribulation presses inwardly in the latter days, it turns the will back toward God and toward obedience.

**Jer 30:7** (H6869B tsa.rah) [M03-D-VCG-04]
> Jer 30:7 Alas ! That day is so great there is none like it; it is a time of distress for Jacob ; yet he shall be saved out of it.
_Meaning of the term here:_ The distress of Jacob is so singular and overwhelming that no comparable moment exists in history, yet the verse frames it not as final but as a crisis from which salvation will emerge.

**Luk 2:48** (G3600 odunaō) [M03-D-VCG-05]
> Luk 2:48 And when his parents saw him , they were astonished . And his mother said to him , " Son , why have you treated us so ? Behold , your father and I have been searching for you in great distress ."
_Meaning of the term here:_ Mary describes the anguish she and Joseph experienced searching for the lost Jesus—the anguish is the painful inner distress of parental fear and grief over a missing child, expressed directly to him.

**2Cor 2:4** (G4928 sunochē) [M03-D-VCG-05]
> 2Cor 2:4 For I wrote to you out of much affliction and anguish of heart and with many tears , not to cause you pain but to let you know the abundant love that I have for you .
_Meaning of the term here:_ The anguish is seated in the heart and accompanied by many tears, originating in Paul's profound inner distress over the Corinthian situation; it is a constituent of love-driven pastoral pain, not hostility.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.6 Groaning and Sighing -->

**Sub-group description (from analytical record):**

> This sub-group names the involuntary or deliberate vocal and bodily expression of grief through groaning, sighing, and travail-like utterance. The meanings consistently show groaning and sighing as the deep inner pressure of grief or suffering finding its outward voice — often rising to God as a cry or appeal. Israel groans under slavery and their cry rises to God covenantally. The Spirit intercedes with groanings too deep for words within the believer's spirit. All creation groans together in birth-pain anguish oriented toward redemption. The travail vocabulary belongs here: ōdinō names the consuming, involuntary anguish of labour used metaphorically for apostolic inner travail. The unifying characteristic is grief expressed as the groan, sigh, or travail-cry — the involuntary or willed utterance of inner suffering that moves toward God.

**Key verses for this characteristic:**

**Exo 2:23** (H0584 a.nach) [M03-E-VCG-01]
> Exo 2:23 During those many days the king of Egypt died , and the people of Israel groaned because of their slavery and cried out for help. Their cry for rescue from slavery came up to God .
_Meaning of the term here:_ Israel groans and sighs under slavery and their cry rises to God; the sighing is the involuntary inner expression of a people whose suffering is so heavy it escapes them as a groan seeking divine attention.

**Exo 2:24** (H5009 ne.a.qah) [M03-E-VCG-01]
> Exo 2:24 And God heard their groaning , and God remembered his covenant with Abraham , with Isaac , and with Jacob .
_Meaning of the term here:_ God hears Israel's groaning under slavery and remembers his covenant; the groan is the inner cry of oppressed suffering that rises to God and triggers covenantal faithfulness and action.

**Psa 38:8** (H5100 ne.ha.mah) [M03-E-VCG-01]
> Psa 38:8 I am feeble and crushed ; I groan because of the tumult of my heart .
_Meaning of the term here:_ Groaning rises from 'the tumult of my heart' — it is the audible outflow of an inner turmoil that has also left the psalmist feeble and crushed physically, locating groaning squarely in the anguished heart.

**Rom 8:22** (G4959 sustenazō) [M03-E-VCG-02]
> Rom 8:22 For we know that the whole creation has been groaning together in the pains of childbirth until now .
_Meaning of the term here:_ The whole creation groans together as in childbirth labor pains, depicting a universal, shared inner anguish oriented toward future redemption—the groaning is collective and expectant rather than hopeless.

**Rom 8:26** (G4726 stenagmos) [M03-E-VCG-02]
> Rom 8:26 Likewise the Spirit helps us in our weakness . For we do not know what to pray for as we ought , but the Spirit himself intercedes for us with groanings too deep for words .
_Meaning of the term here:_ The Spirit intercedes for believers with groanings too deep for words, stepping into the inner weakness where human prayer fails; the groan is the Spirit's own expression within the believer's spirit before God.

**Gal 4:19** (G5605 ōdinō) [M03-E-VCG-02]
> Gal 4:19 my little children , for whom I am again in the anguish of childbirth until Christ is formed in you !
_Meaning of the term here:_ Paul describes his apostolic labor in terms of childbirth anguish, an intense inner travail of love directed toward the Galatians until Christ is fully formed in them—grief here is generative, purposeful, and relational.

**Job 3:24** (H0585 a.na.chah) [M03-E-VCG-03]
> Job 3:24 For my sighing comes instead of my bread , and my groanings are poured out like water .
_Meaning of the term here:_ Job says his sighing comes instead of bread — it has replaced the basic sustenance of life, showing that grief has become so constant and consuming it crowds out even the body's fundamental needs.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.7 Pain and Inner Ache -->

**Sub-group description (from analytical record):**

> This sub-group names grief at the level of pain — the ache, wound, and soreness of the inner person. The meanings consistently describe a suffering felt as pain in body and soul simultaneously, often persistent and inescapable. The servant is a man of sorrows, deeply familiar with grief, bearing the people's sorrows as a burden. Unceasing pain erodes trust in the divine relationship. The heart can ache beneath outward laughter. The birth-pangs vocabulary of che.vel-B uses labour-pain imagery consistently as a metaphor for acute, involuntary seizure of inner anguish. The unifying characteristic is pain as the primary phenomenological quality of grief — what grief feels like from within.

**Key verses for this characteristic:**

**Isa 53:3** (H4341 makh.ov) [M03-F-VCG-01]
> Isa 53:3 He was despised and rejected by men , a man of sorrows , and acquainted with grief ; and as one from whom men hide their faces he was despised , and we esteemed him not .
_Meaning of the term here:_ Pain defines the servant's identity — he is a man of sorrows, deeply familiar with grief; his inner life is marked by suffering, and others respond by hiding their faces, intensifying his isolation.

**Dan 6:20** (H6088 a.tsav) [M03-F-VCG-01]
> Dan 6:20 As he came near to the den where Daniel was, he cried out in a tone of anguish . The king declared to Daniel , "O Daniel , servant of the living God , has your God , whom you serve continually , been able to deliver you from the lions ?"
_Meaning of the term here:_ The king cries out in a tone of anguish, revealing intense inner distress of soul over Daniel's fate; his anxious question shows that the anguish is driven by urgent uncertainty and desperate hope.

**Job 5:18** (H3510 ka.av) [M03-F-VCG-02]
> Job 5:18 For he wounds , but he binds up ; he shatters , but his hands heal .
_Meaning of the term here:_ God wounds but also binds up, shatters but also heals — the pain he inflicts is not final but purposive, placed within a frame of restoration that gives suffering a redemptive direction.

**Jer 15:18** (H3511 ke.ev) [M03-F-VCG-02]
> Jer 15:18 Why is my pain unceasing , my wound incurable , refusing to be healed ? Will you be to me like a deceitful brook , like waters that fail ?
_Meaning of the term here:_ Pain is described as unceasing, like an incurable wound refusing to heal; the prophet questions whether God himself has become unreliable, showing that persistent pain erodes trust in the divine relationship.

**Isa 13:8** (H2256B che.vel) [M03-F-VCG-03]
> Isa 13:8 They will be dismayed : pangs and agony will seize them; they will be in anguish like a woman in labor . They will look aghast at one another ; their faces will be aflame .
_Meaning of the term here:_ Pain seizes the inner person like labor pangs gripping a woman in childbirth; it produces visible outer symptoms — aghast faces and burning shame — revealing the depth of inner anguish.

<!-- /EVIDENCE -->

<!-- EVIDENCE: Ch2 — §2.8 Bitterness of Soul -->

**Sub-group description (from analytical record):**

> This sub-group names the specific inner quality of bitterness that arises from grief, suffering, loss, and divine dealings — the soul's experience of something that has become harsh, sharp, and without sweetness. The meanings consistently show bitterness as an intensification or colouring of grief: God fills the inner being with bitterness to saturation, leaving no room for relief; bitterness is located in the heart as a private inner experience no outsider can share; a foolish son inflicts sharp bitter pain on his mother through his failure; harshness produces bitterness in another person's spirit. This is bitterness-of-soul rather than anger-bitterness, arising from grief, loss, suffering, and divine dealings — what grief tastes like when it is at its sharpest.

**Key verses for this characteristic:**

**Gen 26:35** (H4786 mo.rah) [M03-G-VCG-01]
> Gen 26:35 and they made life bitter for Isaac and Rebekah .
_Meaning of the term here:_ Esau's foreign wives made life itself bitter for Isaac and Rebekah; the bitterness is a pervasive inner distress inflicted on the parents by the relational and spiritual friction of these marriages.

**Job 9:18** (H4472 mam.ror) [M03-G-VCG-01]
> Job 9:18 he will not let me get my breath , but fills me with bitterness .
_Meaning of the term here:_ Job says God fills him with bitterness and will not let him catch his breath, showing bitterness as an overwhelming inner quality — a suffocating state of spirit imposed by unrelenting divine pressure.

**Pro 14:10** (H4787 mor.rah) [M03-G-VCG-01]
> Pro 14:10 The heart knows its own bitterness , and no stranger shares its joy .
_Meaning of the term here:_ Bitterness is located in the heart as a private inner experience that no outsider can fully know or share; it is sealed within the self.

**Pro 17:25** (H4470 me.mer) [M03-G-VCG-01]
> Pro 17:25 A foolish son is a grief to his father and bitterness to her who bore him .
_Meaning of the term here:_ Bitterness is the specific anguish a foolish son causes his mother, a sharp inner pain directed at her by his failure.

**Lam 3:15** (H4844 ma.ror) [M03-G-VCG-01]
> Lam 3:15 He has filled me with bitterness ; he has sated me with wormwood .
_Meaning of the term here:_ Bitterness is experienced as something God fills the person with—a total saturation of the inner being with a harsh, wormwood-like quality that leaves no room for sweetness or relief.

**Col 3:19** (G4087 pikrainō) [M03-G-VCG-01]
> Col 3:19 Husbands , love your wives , and do not be harsh with them .
_Meaning of the term here:_ Husbands are warned not to embitter their wives—an inner relational act that wounds the wife's spirit; harshness produces bitterness in another person, making it a destructive interpersonal inner impact.

<!-- /EVIDENCE -->
