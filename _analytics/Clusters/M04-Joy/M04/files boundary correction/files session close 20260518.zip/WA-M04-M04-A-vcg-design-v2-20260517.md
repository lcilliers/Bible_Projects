# WA-M04-M04-A-vcg-design-v2-20260517

**Sub-group:** M04-A — Exultation in YHWH: Vertical Rejoicing Directed Toward God  
**Phase:** 7 v2 — VCG design  
**Date:** 2026-05-17  
**Governing instruction:** wa-sessionb-cluster-instruction-v2_3-20260517 §10  
**Primary input:** wa-cluster-M04-subgroup-meanings-v2-20260517.md §2  
**Input verse count:** 84  

---

## M04-A-VCG-01 — God-Directed Exultation: Rejoicing Toward YHWH as Object and Source

**Context description:** This VCG names the core register of M04-A: inner exultation, gladness, and rejoicing whose explicit object or ground is YHWH himself, or God's own joy directed toward his people. The soul rejoices in God's salvation (Psa 35:9), the heart is glad in his holy name (Psa 13:5), the people exult in God's name all day long (Psa 89:16), and the prophet resolves to rejoice in the Lord despite total material loss (Hab 3:18). God's own delight toward his people is equally in scope: God rejoices over his people with loud singing (Zep 3:17); God rejoices in Jerusalem (Isa 65:19); God's inner delight in doing good to his people is rooted in all his heart and soul (Jer 32:41). Also included are creation and cosmic rejoicing called forth by divine sovereignty (1Ch 16:31; Psa 96:11; Isa 35:1 — desert personified in joy at divine restoration), and the pure gladness of entering God's presence (Psa 21:6; Dan 6:23). The defining characteristic: the rejoicing is oriented toward God as the named object or is God's own affective delight toward his creation.

**Member verses (complete):**

| vc_id | Reference | Term |
|---|---|---|
| 51027 | Exo 18:9 | cha.dah |
| 23586 | Deu 30:9 | su.s |
| 23356 | 1Ch 16:31 | gil_verb |
| 51026 | Psa 21:6 | cha.dah |
| 23357 | Psa 2:11 | gil_verb |
| 23358 | Psa 9:14 | gil_verb |
| 23354 | Psa 35:9 | gil_verb |
| 23360 | Psa 13:5 | gil_verb |
| 23361 | Psa 14:7 | gil_verb |
| 23362 | Psa 16:9 | gil_verb |
| 23584 | Psa 35:9 | su.s |
| 23589 | Psa 40:16 | su.s |
| 23398 | Psa 43:4 | gil |
| 23401 | Psa 45:15 | gil |
| 23366 | Psa 48:11 | gil_verb |
| 23367 | Psa 51:8 | gil_verb |
| 23368 | Psa 53:6 | gil_verb |
| 23579 | Psa 63:5 | re.na.nah |
| 23588 | Psa 19:5 | su.s |
| 23363 | Psa 21:1 | gil_verb |
| 23402 | Psa 65:12 | gil |
| 23590 | Psa 68:3 | su.s |
| 23591 | Psa 70:4 | su.s |
| 23364 | Psa 31:7 | gil_verb |
| 23365 | Psa 32:11 | gil_verb |
| 23369 | Psa 89:16 | gil_verb |
| 23393 | Psa 96:11 | gil_verb |
| 23370 | Psa 97:1 | gil_verb |
| 23371 | Psa 97:8 | gil_verb |
| 23580 | Psa 100:2 | re.na.nah |
| 23372 | Psa 118:24 | gil_verb |
| 23592 | Psa 119:14 | su.s |
| 23593 | Psa 119:162 | su.s |
| 23373 | Psa 149:2 | gil_verb |
| 23380 | Isa 25:9 | gil_verb |
| 23381 | Isa 29:19 | gil_verb |
| 23382 | Isa 41:16 | gil_verb |
| 23397 | Isa 49:13 | gil_verb |
| 23383 | Isa 61:10 | gil_verb |
| 23583 | Isa 61:10 | su.s |
| 23595 | Isa 62:5 | su.s |
| 23596 | Isa 64:5 | su.s |
| 23384 | Isa 65:18 | gil_verb |
| 23597 | Isa 65:18 | su.s |
| 23385 | Isa 65:19 | gil_verb |
| 23598 | Isa 65:19 | su.s |
| 23386 | Isa 66:10 | gil_verb |
| 23599 | Isa 66:10 | su.s |
| 23600 | Isa 66:14 | su.s |
| 23605 | Jer 32:41 | su.s |
| 23388 | Joe 2:21 | gil_verb |
| 23389 | Joe 2:23 | gil_verb |
| 23355 | Hab 3:18 | gil_verb |
| 23391 | Zep 3:17 | gil_verb |
| 23604 | Zep 3:17 | su.s |
| 23394 | Zec 9:9 | gil_verb |
| 23392 | Zec 10:7 | gil_verb |
| 51029 | Dan 6:23 | te.ev |

**Member count: 58**

**Anchor verse:** vc_id 23398 — Psa 43:4 — gil  
**Rationale:** "God himself is called 'my exceeding joy' — the rejoicing is not merely felt before God but found in God as its very substance." This is the most concentrated statement of the VCG's defining phenomenon: God as the actual substance of the psalmist's joy, not merely its occasion.

**Dual-membership flags:** None. All 58 are cleanly God-directed.

---

## M04-A-VCG-02 — Inverted, Absent, or Corrupt Joy: Rejoicing by Negation

**Context description:** This VCG names the verses in M04-A where the rejoicing vocabulary evidences the characteristic by inversion, absence, or moral corruption. The register shows what joy IS by showing what it is not, or what it becomes when misdirected. Job's cursing of the night of his birth by wishing it barren of any joyful cry (Job 3:7), the perverse exultation of extreme sufferers who are glad to find the grave (Job 3:22), the wicked's brief triumphing explicitly declared transient (Job 20:5), the feared gloating of enemies over the psalmist (Psa 13:4), joy stripped from Moab's fertile land by divine judgment (Jer 48:33), enemy joy at Zion's suffering (Lam 1:21), Edom's ironic and self-dooming exultation (Lam 4:21), the rhetorical "shall we rejoice?" where any joy is impossible given the sword at hand (Eze 21:10), Israel's illegitimate hollow celebration built on spiritual prostitution (Hos 9:1), idolatrous priests' joy at the golden calf now lost with its departure (Hos 10:5), joy cut off from God's house when provision fails (Joe 1:16), the Babylonian conqueror's predatory gladness (Hab 1:15), the wicked's rejoicing in evil (Pro 2:14), and the prohibited impulse to exult at an enemy's fall (Pro 24:17). Also included: God's delight in bringing ruin as the inverse of his former delight in doing Israel good (Deu 28:63), and the void of joy that is Job 3:6 (joylessness as the desired curse).

**Member verses (complete):**

| vc_id | Reference | Term |
|---|---|---|
| 23585 | Deu 28:63 | su.s |
| 51028 | Job 3:6 | cha.dah |
| 23581 | Job 3:7 | re.na.nah |
| 23400 | Job 3:22 | gil |
| 23587 | Job 3:22 | su.s |
| 23582 | Job 20:5 | re.na.nah |
| 23359 | Psa 13:4 | gil_verb |
| 23403 | Isa 16:10 | gil |
| 23404 | Jer 48:33 | gil |
| 23601 | Lam 1:21 | su.s |
| 23602 | Lam 4:21 | su.s |
| 23603 | Eze 21:10 | su.s |
| 23399 | Hos 9:1 | gil |
| 23387 | Hos 10:5 | gil_verb |
| 23406 | Joe 1:16 | gil |
| 23390 | Hab 1:15 | gil_verb |
| 23374 | Pro 2:14 | gil_verb |
| 23377 | Pro 24:17 | gil_verb |

**Member count: 18**

**Anchor verse:** vc_id 23400 — Job 3:22 — gil  
**Rationale:** "The sufferers Job describes rejoice exceedingly at finding the grave; their inner state is a perverse exultation directed toward death as relief, showing how extreme anguish can invert the normal objects of joy." This is the sharpest statement of the VCG's defining phenomenon: the joy vocabulary used to name an inversion so complete that death becomes the object of gladness.

**Dual-membership flags:** None.

---

## M04-A-VCG-03 — Relational and Natural Gladness: Joy in Human Bonds and Creation's Response

**Context description:** This VCG names the M04-A verses where rejoicing arises from human relational bonds, parental delight, relational intimacy, or creation's personified response — neither explicitly God-directed (VCG-01) nor inverted/corrupt (VCG-02). A father's deep exultation at a righteous son (Pro 23:24), a mother's joy at a wise child (Pro 23:25), the relational exultation of being drawn into the beloved king's presence (Song 1:4 — which has divine resonance but is primarily expressed toward the human beloved), the spontaneous harvest-type joy at military victory (Isa 9:3), and the land and desert personified in joyful response to coming restoration (Isa 35:1 ×2; Isa 35:2 — which anticipates eschatological renewal rather than naming God as explicit object). The missing XREF verse (Dan 1:10, vc_id 23405, gil) is assigned here by term context: the word gil in Daniel 1 concerns the king's face/countenance and relational favour — the closest VCG without a known meaning is this relational register.

**Member verses (complete):**

| vc_id | Reference | Term |
|---|---|---|
| 23375 | Pro 23:24 | gil_verb |
| 23376 | Pro 23:25 | gil_verb |
| 23378 | Song 1:4 | gil_verb |
| 23379 | Isa 9:3 | gil_verb |
| 23395 | Isa 35:1 | gil_verb |
| 23594 | Isa 35:1 | su.s |
| 23396 | Isa 35:2 | gil_verb |
| 23405 | Dan 1:10 | gil *(missing — XREF assigned by term+reference to this VCG)* |

**Member count: 8**

**Anchor verse:** vc_id 23375 — Pro 23:24 — gil_verb  
**Rationale:** "A father whose son is righteous will greatly rejoice — the child's moral character is the direct cause of the father's deep inner exultation and delight." This is the most analytically clear statement in VCG-03: rejoicing arising from a human relational bond (parent-child), explicitly inner, and clearly distinguished from both God-directed exultation and corrupt joy.

**Dual-membership flags:** Song 1:4 (vc_id 23378) has a dual-membership note — the beloved king in Song 1 has messianic/divine resonance in the tradition, meaning this verse is M04-A-VCG-01 adjacent. Primary assignment: VCG-03 (relational gladness toward the human beloved). Secondary note: divine-king reading would place it in VCG-01.

---

## Verification

**VCG member sums: 58 + 18 + 8 = 84, which matches M04-A input count of 84 ✓**

All 84 vc_ids accounted for. No vc_id appears in more than one VCG (except the noted dual-membership observation on 23378 which is assigned primary VCG-03 only). No vc_ids invented. All sourced from the meanings report §2.

---

*End of WA-M04-M04-A-vcg-design-v2-20260517.md*
