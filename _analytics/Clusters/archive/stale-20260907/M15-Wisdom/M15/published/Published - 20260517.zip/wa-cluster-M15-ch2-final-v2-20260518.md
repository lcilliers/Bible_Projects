## 2. The characteristics in this study

Scripture's vocabulary for the cognitive and receptive life of the inner person organises into eight related characteristics — each a distinct way the person receives, holds, works with, and is shaped by understanding, wisdom, and the knowledge of God. The chapters that follow treat each at depth; this chapter gives the reader a working sense of every characteristic before those deeper treatments begin.

### 2.1 Wisdom as holistic inner character and orientation

Wisdom, in the terms this study follows, is not a skill or a collection of correct ideas. It is a settled inner character — a whole-person orientation that shapes how a person perceives situations, makes decisions, and carries themselves before God and others. Where other characteristics in this study name particular capacities or operations of the inner life, wisdom names the constituted quality of the person as a whole: the person *is* wise, or is not, in the same way that a person has integrity or lacks it.

The scope of this characteristic is significant. The terms that carry it — including the Hebrew *chokmah* and the Greek *sophia* — span from the craft-wisdom of the skilled artisan to the moral-spiritual character that fears God and turns from evil. They name wisdom both as God's own attribute and as the quality he gives to those who ask. As Dan 2:20 shows, wisdom belongs to God first: "Blessed be the name of God forever and ever, to whom belong wisdom and might." The human person's wisdom is always participated, never self-generated. Jam 1:5 makes the same point from the human side: "If any of you lacks wisdom, let him ask God, who gives generously to all without reproach, and it will be given him." Wisdom is asked for and received, not produced.

What distinguishes wisdom from understanding — the characteristic immediately adjacent to it in this study — is that wisdom is the constituted character of the whole person, while understanding is the receptive faculty by which that person grasps what is being shown. Wisdom is what you are; understanding is how you take in what is given.

> Terms that name wisdom as a constituted holistic quality of the inner person — a settled orientation of the whole person that shapes perception, decision, and character. Includes the structural opposite (unwise). Spirit-given, covenantally oriented, morally constitutive.

> Dan 2:20 Daniel answered and said : " Blessed be the name of God forever and ever , to whom belong wisdom and might .

> Jam 1:5 If any of you lacks wisdom , let him ask God , who gives generously to all without reproach , and it will be given him .

> Pro 16:23 The heart of the wise makes his speech judicious and adds persuasiveness to his lips .

> Rom 8:5 For those who live according to the flesh set their minds on the things of the flesh , but those who live according to the Spirit set their minds on the things of the Spirit .

> Phili 2:2 complete my joy by being of the same mind , having the same love , being in full accord and of one mind .

> Pro 26:12 Do you see a man who is wise in his own eyes ? There is more hope for a fool than for him .

> 1Cor 1:21 For since , in the wisdom of God , the world did not know God through wisdom , it pleased God through the folly of what we preach to save those who believe .

> Neh 8:8 They read from the book , from the Law of God , clearly , and they gave the sense , so that the people understood the reading .

> Psa 111:10 The fear of the Lord is the beginning of wisdom ; all those who practice it have a good understanding . His praise endures forever !

> Exo 31:4 to devise artistic designs , to work in gold , silver , and bronze ,

### 2.2 Understanding as inner perceptive faculty

Understanding, as this study traces it, is the inner capacity that receives and grasps what is being shown. It is not a store of knowledge already held — that belongs to a different characteristic — but the active capacity to take in meaning: to perceive, to comprehend, to open to what is being communicated. Where wisdom is the settled orientation of the whole person, understanding is the receptive side of that orientation — the capability by which revelation, instruction, or truth enters the inner life and is grasped.

This faculty is both divine and creaturely. At its heights, it is beyond human reach. Isa 40:28 places it beyond all probing: "The Lord is the everlasting God, the Creator of the ends of the earth. He does not faint or grow weary; his understanding is unsearchable." At its humblest, it is the gift that God places in those who ask — as Job 38:36 asks, "Who has put wisdom in the inward parts or given understanding to the mind?" — God himself named as the giver.

The moral conditioning of this faculty is one of its distinguishing features. Understanding is not merely an intellectual capacity that works or fails to work; it is enabled by humility before God and blocked by hardness of heart. Isa 6:10 captures the negative case starkly: "Make the heart of this people dull, and their ears heavy, and blind their eyes; lest they see with their eyes, and hear with their ears, and understand with their hearts, and turn and be healed." The faculty of understanding and the moral condition of the heart are not separable.

Understanding in this sense is narrower than wisdom — it is the receptive act, not the constituted character — and wider than discernment, which applies judgment to a specific situation. Understanding is the basic opening of the person to what is true.

> Terms that name the inner capacity of understanding — the capacity to receive, perceive, and grasp what is being revealed or communicated. Morally conditioned: the faculty is enabled by humility before God and blocked by heart-dullness. Includes the structural opposite (senseless).

> Isa 40:28 Have you not known ? Have you not heard ? The Lord is the everlasting God , the Creator of the ends of the earth . He does not faint or grow weary ; his understanding is unsearchable .

> Job 38:36 Who has put wisdom in the inward parts or given understanding to the mind ?

> 1Ki 3:9 Give your servant therefore an understanding mind to govern your people , that I may discern between good and evil , for who is able to govern this your great people ?"

> Isa 6:10 Make the heart of this people dull , and their ears heavy , and blind their eyes ; lest they see with their eyes , and hear with their ears , and understand with their hearts , and turn and be healed ."

> Heb 5:14 But solid food is for the mature , for those who have their powers of discernment trained by constant practice to distinguish good from evil .

> Luk 24:45 Then he opened their minds to understand the Scriptures ,

> Act 24:25 And as he reasoned about righteousness and self-control and the coming judgment , Felix was alarmed and said , " Go away for the present . When I get an opportunity I will summon you ."

### 2.3 Knowledge as inner content and covenantal knowing

Knowledge, in the terms this study follows, carries two distinct but related emphases. The first is knowledge as inner content — the information, understanding, and recognition held within the knowing self. The second, and in Scripture's treatment the more weighty, is knowledge as a relational and covenantal orientation: knowing God, being known by God, and the moral and communal implications that flow from that relationship.

The covenantal dimension is what gives this characteristic its particular weight within the family. Amo 3:2 shows God himself using the language of knowing to name elective relationship: "You only have I known of all the families of the earth; therefore I will punish you for all your iniquities." Knowing here is not acquaintance; it is covenant-constituting election. From the human side, Hos 6:3 expresses the same covenantal orientation in pursuit: "Let us know; let us press on to know the Lord; his going out is sure as the dawn." Knowledge of God is something to be pursued, grown into, and pressed toward.

The absence of this knowledge is correspondingly catastrophic. Hos 4:6 delivers the divine verdict: "My people are destroyed for lack of knowledge." The eschatological horizon of this characteristic is among the clearest in the family: Hab 2:14 promises that "the earth will be filled with the knowledge of the glory of the Lord as the waters cover the sea" — a fullness of knowing that is not yet, but will be.

Knowledge in this study is distinguished from understanding — which is the receptive faculty — and from wisdom — which is the whole-person orientation. Knowledge is the content and relationship held within the inner person, orienting them toward or away from God.

> Terms that name knowledge as both inner content held in the knowing self and the constitutive relational orientation of knowing God. Includes the covenantal knowing of God and its structural opposite (spiritual ignorance/agnoeō).

> Psa 139:6 Such knowledge is too wonderful for me; it is high ; I cannot attain it .

> Amo 3:2 "You only have I known of all the families of the earth ; therefore I will punish you for all your iniquities .

> Jos 4:24 so that all the peoples of the earth may know that the hand of the Lord is mighty , that you may fear the Lord your God forever ."

> Hos 6:3 Let us know ; let us press on to know the Lord ; his going out is sure as the dawn ; he will come to us as the showers , as the spring rains that water the earth ."

> Hos 4:6 My people are destroyed for lack of knowledge ; because you have rejected knowledge , I reject you from being a priest to me. And since you have forgotten the law of your God , I also will forget your children .

> Pro 1:7 The fear of the Lord is the beginning of knowledge ; fools despise wisdom and instruction .

> Gen 2:17 but of the tree of the knowledge of good and evil you shall not eat , for in the day that you eat of it you shall surely die ."

> Rom 8:28 And we know that for those who love God all things work together for good , for those who are called according to his purpose .

> Rom 10:3 For , being ignorant of the righteousness of God , and seeking to establish their own , they did not submit to God's righteousness .

> Gen 8:11 And the dove came back to him in the evening , and behold , in her mouth was a freshly plucked olive leaf . So Noah knew that the waters had subsided from the earth .

> Gen 4:1 Now Adam knew Eve his wife , and she conceived and bore Cain , saying , "I have gotten a man with the help of the Lord ."

> Hab 2:14 For the earth will be filled with the knowledge of the glory of the Lord as the waters cover the sea .

### 2.4 Discernment and practical judgment

Discernment, as this study uses the term, is the applied perceptive act — the inner capacity to read a situation wisely and to make right distinctions in it. Where wisdom is the settled character of the whole person and understanding is the faculty that receives what is offered, discernment is the capacity that judges: it evaluates, weighs, and determines what is right, true, or good in a particular case.

This characteristic has an important quality that sets it apart from the others in this family: the underlying capacity is directionally neutral. The same inner quality of shrewd, penetrating judgment can serve righteousness or cunning depending on where it is directed. Gen 3:1 makes the dark case explicit — "the serpent was more crafty than any other beast of the field" — where the same capacity for keen practical judgment that elsewhere serves wisdom here serves deception.

In its right orientation, discernment is conscience-adjacent — the inner evaluation that Scripture commends turns toward the self as well as toward situations. 1Cor 11:31 captures the reflexive movement: "But if we judged ourselves truly, we would not be judged." Self-discernment — honest inner assessment — is not a luxury; it is a safeguard. Isa 52:13 shows the positive form in the figure of the Servant: "Behold, my servant shall act wisely; he shall be high and lifted up, and shall be exalted" — *sa.khal* naming the practical wisdom that governs right action in the world.

Discernment is narrower than wisdom (it is the act, not the constituted character) and more evaluative than understanding (it judges, not merely receives).

> Terms that name the applied perceptive act — judging situations wisely, making right moral-practical distinctions, and the conscience-adjacent evaluation of thoughts. Includes directionally neutral terms (same inner quality serves righteousness or cunning depending on object).

> Isa 52:13 Behold , my servant shall act wisely ; he shall be high and lifted up , and shall be exalted .

> 1Cor 11:31 But if we judged ourselves truly, we would not be judged .

> Gen 15:6 And he believed the Lord , and he counted it to him as righteousness .

> Psa 73:16 But when I thought how to understand this , it seemed to me a wearisome task,

> Psa 34:8 Oh, taste and see that the Lord is good ! Blessed is the man who takes refuge in him !

> Gen 3:1 Now the serpent was more crafty than any other beast of the field that the Lord God had made . He said to the woman , "Did God actually say , 'You shall not eat of any tree in the garden '?"

> Rom 2:15 They show that the work of the law is written on their hearts , while their conscience also bears witness , and their conflicting thoughts accuse or even excuse them

### 2.5 Deliberative planning, counsel, and purposive intent

This characteristic names the inner capacity to look forward — to form intent, to devise plans, to give and receive counsel, and to act with deliberate purpose toward an end. It is the purposive orientation of the inner person, the faculty of the will turned toward the future and engaged with what shall be done.

The scope of this characteristic spans the divine and the human without collapsing the distinction between them. God plans and purposes, and his purposes stand. Isa 14:24 announces it directly: "As I have planned, so shall it be, and as I have purposed, so shall it stand." The human act of deliberate planning — seeking counsel, forming intent, making provision — participates in that same vocabulary. But where God's plans are sovereign and sure, human planning takes place in dependence, and sometimes in folly. Rev 17:17 shows that even human deliberation serves purposes beyond itself: "for God has put it into their hearts to carry out his purpose by being of one mind and handing over their royal power to the beast, until the words of God are fulfilled." The characteristic of purposive intent, in this verse, is itself an instrument of divine sovereignty.

What distinguishes this characteristic from discernment is its orientation: discernment reads the present situation; planning and purposive intent reach forward into what has not yet happened. What distinguishes it from wisdom is its active, volitional thrust — wisdom is the settled character; this is the capacity that forms and executes deliberate intent. 2Pe 3:9 shows its divine register at its most pastorally significant: "not wishing that any should perish, but that all should reach repentance" — God's purposive will as the ground of patience.

> Terms that name the inner capacity of purposive forward-orientation — forming intent, devising plans, giving and receiving counsel, making deliberate decisions. Includes divine and human purposive activity.

> 2Pe 3:9 The Lord is not slow to fulfill his promise as some count slowness , but is patient toward you , not wishing that any should perish , but that all should reach repentance .

> Rev 17:17 for God has put it into their hearts to carry out his purpose by being of one mind and handing over their royal power to the beast , until the words of God are fulfilled .

> Isa 14:24 The Lord of hosts has sworn : " As I have planned , so shall it be, and as I have purposed , so shall it stand ,

> 2Sa 16:23 Now in those days the counsel that Ahithophel gave was as if one consulted the word of God ; so was all the counsel of Ahithophel esteemed, both by David and by Absalom .

> Jer 29:11 For I know the plans I have for you, declares the Lord , plans for welfare and not for evil , to give you a future and a hope .

> Lam 2:17 The Lord has done what he purposed ; he has carried out his word , which he commanded long ago ; he has thrown down without pity ; he has made the enemy rejoice over you and exalted the might of your foes .

> Exo 7:23 Pharaoh turned and went into his house , and he did not take even this to heart .

> Rom 13:14 But put on the Lord Jesus Christ , and make no provision for the flesh , to gratify its desires .

### 2.6 Meditative and reflective inner activity

Meditative and reflective inner activity names what happens when the inner person turns on what it has received — pondering, musing, considering at length, reasoning within itself. The other characteristics in this study are largely oriented outward: toward God who gives wisdom, toward truth that can be known, toward situations that require judgment, toward ends that require planning. Meditative inner activity is the movement inward: the mind working over what is already present to it.

The inner character of this activity — the fact that it happens within, not merely about external things — is what the evidence holds. Luk 5:22 locates it precisely: "When Jesus perceived their thoughts, he answered them, 'Why do you question in your hearts?'" The inner questioning, the reasoning-within, is a heart-activity — not a neutral cognitive process but something that happens in the inner person and is visible to God. Heb 4:12 confirms both the interiority and its transparency: "For the word of God is living and active, sharper than any two-edged sword, piercing to the division of soul and of spirit, of joints and of marrow, and discerning the thoughts and intentions of the heart."

This characteristic is distinguished from inner thought-content — the adjacent characteristic in this study — by its activity. Formed thoughts are the objects the mind holds; meditative inner activity is the process of turning on and over those objects. The Psalmist's confession in Psa 119:97 — "Oh how I love your law! It is my meditation all the day" — names this as an ongoing, continuous, directed movement of the inner person, not a single moment of reception.

As noted in the opening chapter, meditative activity is the one characteristic in this family that Scripture does not attribute to God himself — marking it as the distinctively creaturely response mode within the family.

> Terms that name the inner turning of the mind on received material — musing, pondering, the inner dialogue of self-reasoning, and the contemplative considering of a person before God. Activity-oriented (distinct from static thought-content).

> Luk 5:22 When Jesus perceived their thoughts , he answered them , " Why do you question in your hearts ?

> Heb 4:12 For the word of God is living and active , sharper than any two-edged sword , piercing to the division of soul and of spirit , of joints and of marrow , and discerning the thoughts and intentions of the heart .

> Mem Psa 119:97 Oh how I love your law ! It is my meditation all the day .

> Dan 7:8 I considered the horns , and behold , there came up among them another horn , a little one, before which three of the first horns were plucked up by the roots . And behold , in this horn were eyes like the eyes of a man , and a mouth speaking great things .

### 2.7 Inner thought-content — the mind's formed thoughts

This characteristic names what the mind holds — the formed thoughts that exist as objects within the inner person, capable of being guarded, captured, led astray, examined, or disclosed. Where meditative activity is the dynamic process of the mind working over material, formed thought-content is the settled result: the thoughts that are present, held, carried within.

The vulnerability of thought-content is one of its most striking features in the evidence. 2Cor 4:4 describes what happens when the formed thoughts of the mind are spiritually closed: "In their case the god of this world has blinded the minds of the unbelievers, to keep them from seeing the light of the gospel of the glory of Christ, who is the image of God." The noun here — *noēma*, the formed thought-content of the mind — is what is blinded; the inner object-space of thought is the site of spiritual contest.

The same inner space can be turned upward. Psa 139:17 speaks of God's thoughts directed toward the human person: "How precious to me are your thoughts, O God! How vast is the sum of them!" The same vocabulary of formed, countable thought-content now runs in the other direction — God's thoughts toward us as the reciprocal of our thoughts toward him.

What distinguishes formed thought-content from knowledge is its static character: knowledge is the relational orientation of the person, held as a living relationship with God; formed thought-content is the held material of the mind, the objects the mind carries within it at any given moment. Both live in the inner person, but they describe different aspects of what it means to be a knowing, thinking creature.

> Terms that name the formed thoughts held within the mind — inner content as objects held, which can be guarded, captured, led astray, or disclosed. Static (distinct from reflective activity).

> 2Cor 4:4 In their case the god of this world has blinded the minds of the unbelievers , to keep them from seeing the light of the gospel of the glory of Christ , who is the image of God .

> Psa 139:17 How precious to me are your thoughts , O God ! How vast is the sum of them!

> 2Ch 1:11 God answered Solomon , " Because this was in your heart , and you have not asked for possessions , wealth , honor , or the life of those who hate you, and have not even asked for long life , but have asked for wisdom and knowledge for yourself that you may govern my people over whom I have made you king ,

### 2.8 Logos — the word as inner-being engagement

This characteristic stands at the far edge of the family, and its scope is unlike any of the others. It names the engagement of the inner person with the living Word — not primarily as an intellectual category, but as the indwelling of Christ himself as the Word of God. The *logos* in this study's evidence is the word that enters and inhabits the inner person, and at its apex it is Christ himself who inhabits.

Col 3:16 states the pattern directly: "Let the word of Christ dwell in you richly, teaching and admonishing one another in all wisdom, singing psalms and hymns and spiritual songs, with thankfulness in your hearts to God." The word of Christ is to dwell — *oikeō*, to make its home — richly within the inner person, and that indwelling issues in teaching, mutual admonition, and corporate worship. This is not the Word as information received and stored — it is the Word as a living presence shaping the inner person from within.

1Cor 14:19 shows the word functioning in its communicative register — "in church I would rather speak five words with my mind in order to instruct others, than ten thousand words in a tongue" — where logos names the intelligible, mind-engaging word that builds up the community.

What distinguishes this characteristic from knowledge is that knowledge names the relational orientation toward God that the inner person holds; this characteristic names the active engagement and indwelling of the Word itself — the word coming in, dwelling, and shaping from within. Of all the characteristics in this family, this one is most explicitly Christological: the Word who indwells is the Word who is Christ.

> the Living Word indwelling the inner being, the embodiment of Christ as the Word of God

> Col 3:16 Let the word of Christ dwell in you richly , teaching and admonishing one another in all wisdom , singing psalms and hymns and spiritual songs , with thankfulness in your hearts to God .

> 1Cor 14:19 Nevertheless , in church I would rather speak five words with my mind in order to instruct others , than ten thousand words in a tongue .

> Rom 14:12 So then each of us will give an account of himself to God .

### 2.9 Supporting characteristics

the evidence in this study includes a number of terms that appear alongside the inner-being characteristics but do not themselves name an inner quality of the person. These are terms that carry a supporting or relational role: functional activities such as translation, arbitration, and teaching; formative practices that shape the inner person from outside; communicative acts such as insisting or urging; or terms that describe resemblance and comparison. Some terms in this group have been flagged for possible reassignment to a different part of the wider research programme.

These supporting characteristics are not inner-being characteristics in their own right — they do not name something the person *has* or *is* at the level of inner life. They appear in the evidence because they occur in proximity to the characteristics that are the proper subject of this study. Chapters 4 through 7 do not treat them at depth; they are acknowledged here so the reader understands what is and is not being claimed in the chapters that follow.

> Terms that carry inner-being relevance in their confirmed verses but do not carry an inner characteristic as their primary semantic load: functional roles (translation, arbitration, teaching), formative activities (training), speech acts (insisting), comparators (resembling), or terms flagged for this study reassignment .