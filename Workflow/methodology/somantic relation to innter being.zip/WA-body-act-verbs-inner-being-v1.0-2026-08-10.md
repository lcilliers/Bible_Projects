# WA — Body-Act Verbs and the Inner Being: a candidate domain (or lens)

- **filename:** WA-body-act-verbs-inner-being-v1.0-2026-08-10.md
- **date timestamp:** 2026-08-10
- **version:** 1.0 (new note)
- **previous outputs referenced:** none directly; arises from a live debate opened around the word *take*, and relates to the Daniel interpretation-questions instrument (`WA-interpretation-questions-v1.0-2026-07-26.md`) and the span-synergy method (`wa-global-span-synergy-method-v1_0-20260809.md`)
- **change-control note:** New note. Captures a debate in which a single example word (*take*) opened onto a recognisable class of physical-act words interwoven with the inner being. Records observation, interpretation, and reflection separately; surfaces one open fork; does **not** decide it.
- **author:** le Roux Cilliers

---

## 1. What this note is

A holding document for an idea that surfaced while debating *take*. The idea is larger than *take*: there appears to be a **class of words whose literal referent is a physical act but whose attested usage runs deep into the inner being** — with borders between the physical and the non-physical that are often genuinely unclear. This note captures the class, three ways it may work, its relation to instruments the programme already has, the chief risk in handling it, and the single decision that has to be made before it becomes anything. It is a working note, not a finding and not a method.

---

## 2. Observation — the starting point: *take* is a radial category

The dictionary root of *take* is physical: to grasp, seize, bring into the hand or into possession. But the physical sense is the **centre of a radial field**, not its boundary. Around it sit: acquiring into possession; depriving another (*take from*, *take away*); receiving or accepting (*take advice*, *take a gift*); consuming (*take medicine*); selecting (*I'll take that one*); capturing by force (*take captive*); perceiving (*take note*, *take in*); and a whole affective family that runs entirely inside the person while borrowing the vocabulary of physical grasp — *take heart*, *take offence*, *take pity*, *take comfort*, *take counsel*.

The physical is therefore the seed, not the tree. *Take* is a fault-line where an outward act is the visible endpoint of an interior sequence — an antecedent state (need, desire, entitlement, fear, love), a volition that directs the reach, a target, and an effect that lands back on the taker and often on another.

## 3. Observation — *take* has compatriots: a class of body-act words

*Take* is one instance of a wider class. The same body-act-to-inner-being fanning is visible — and, importantly, already present in the source-language lemmas, not merely introduced by English translation — in words such as:

- **see** — to perceive, to understand, to have vision;
- **give** — to devote, to surrender, to yield the self;
- **speak** — the mouth externalising the heart;
- **walk** — to conduct one's life; to walk *with* God;
- **take** — to appropriate, into possession or into the self.

The literal referent of each is a bodily act. The attested extension of each reaches into perception, disposition, relation, volition, and moral conduct. The border between the two is, in many verses, not sharp.

## 4. Observation — the programme has already been inside this class

This is not a new frontier so much as the naming of a class the programme has already worked through case by case:

- **Healing (registry 184)** explicitly wrestled with foregrounding inner-being bearing *while registering somatic incidences as somatic* — that is precisely the body-act / inner-being border problem.
- **Cursing (178)** and **blessing (158)** are speech acts — the body-act family under another name.

So at least three registries already sit inside this class. What is new is the recognition that they might be thought about *as a class*, rather than each rediscovering the same border difficulty alone.

---

## 5. Interpretation — the interweaving is probably not one thing

Part of why the borders feel unclear may be that **more than one mechanism is running under the same surface**. At least three are distinguishable:

1. **Metaphor** — the body-act stands *for* an inner operation that is not itself physical (understanding lends itself to *seeing*; conduct to a *path/walk*). No physical act need be occurring.
2. **Metonymy / externalisation** — the physical act is the visible *edge* of an inner movement that is genuinely occurring (speech really does externalise the heart; this is not a figure of speech but a manifestation).
3. **Whole-person act** — the act is neither figure nor mere manifestation, but the interior person acting *through* the body as instrument (*walking with God*).

If this holds, then much of the "unclear border" difficulty simply *is* the difficulty of telling which of the three a given verse is doing. That reframes the border problem from a defect to be solved into a **question to be asked of each verse**.

## 6. Interpretation — a possible directional asymmetry

The words already carried through the synergy run (fear especially) are **inner-anchored**: the state is interior and manifests outward (dread → trembling). The words in this candidate class look **body-anchored**: the act is exterior and extends inward (grasp → appropriation of a disposition).

If that asymmetry is real, the *evidence flows in opposite directions* for the two groups — inner-out versus outer-in — which would change how a verse in each group is interrogated. Speech and somatic acts (cursing, blessing, healing) appear to sit on the seam between the two. This is an interpretation to be tested against corpus evidence, not a settled claim.

## 7. Interpretation — the instrument for this class may already exist

The Daniel **interpretation-questions instrument** was born from exactly this class's characteristic failure: an outward act being wrongly treated as having no inner bearing. Its founding move — *every human act invites a question about the interior behind it and about the source of that interior* — is, in effect, already the interrogative this class needs. Q1 (focused inner being behind a stated outward act), Q2 (implied interior), Q4 (source of state vs source of enablement) are the very questions a body-act verse demands. This suggests the class may need **no new instrument** — only the recognition that these words are its natural subjects.

---

## 8. Reflection — the cardinal risk: observe, do not classify

The chief danger is the one that has bitten the programme before: turning an observation into a rule. The moment *"see always carries inner bearing"* becomes a classification, inner meaning is re-imported into verses where the sight is merely physical — the exact imposition failure the reset was called to end, and the same demotion **faculty** has already undergone (from ontology to the bare question *"does this verse address a faculty, and which?"*).

The class can therefore only ever license a **question** — *where is the border in this verse?* — never a pre-loaded answer. Held as a lens, it sharpens reading. Held as a category, it re-imposes. The line between the two is the whole ballgame.

## 9. Reflection — cultures, interest groups, translation

- Whether the body → inner extension (grasp → appropriate; walk → conduct) is **near-universal across languages** or **language-specific** is a genuine empirical question that cannot be settled from within the corpus alone.
- **Moral valence shifts by frame**: *taking-as-acquisition* reads very differently in an individualist setting than *taking-from-the-collective* reads in a communal one — relevant wherever a collective is the subject (Q8).
- **Frozen idioms lose their body-anchor in translation** (*take heart* rarely surfaces the hand). Translation may therefore *hide the very interweaving* the study wants to see — a standing hazard for any reader-facing output.

## 10. Reflection — on the overwhelm (labelled reflection, offered, not prescribed)

You named that every dimension opens onto another heap of discoveries, and that this is overwhelming. Held as a reflection rather than a claim: that experience may be **a finding about the object, not a failure of method**. The programme's own position is that *the inner being is a system* (the 46 families are not). A system's dimensions interconnect by definition — so each true inroad *will* open onto others. The openness you are meeting is the territory being genuinely reticulate, not you failing to contain it.

If that reading holds, it also points at a practical inroad. The distinction in §11 below — **lens** versus **domain** — is exactly the difference between *a small instrument you carry* and *another large corpus you must exhaustively synergise*. A lens is a question applied to work already scoped; it adds sharpness without adding a heap. A domain is a new body of material to mine. The same insight can be taken either way. Which way it is taken governs whether it lightens the load or adds to it. This is reflection, not direction — the choice is yours.

---

## 11. The open fork — surfaced, not decided

**"A separate genre or domain of operations" can mean two different things, and the difference matters before this note becomes anything:**

- **(A) A domain** — a way of *grouping* a set of words as belonging together, i.e. a new organising structure over the registry / the 47 workspaces.
- **(B) A lens / interrogative** — a set of border-questions *applied to* certain words, which otherwise stay in their existing clusters.

These have very different consequences for the registry and the workspaces, and (per §10) very different consequences for workload.

**Underneath either lies a membership question:** what is the *criterion* for a word being in? For example — is *fear* in (it manifests physically) or out (it is inner-anchored)? Where do speech acts (curse, bless) sit — in the class, or on its seam? Without a criterion, the class has no edge.

*Recommendation held lightly:* (B), a lens, looks the lower-risk and lower-load reading — it avoids the classification trap of §8 and adds no new heap — but this is offered for your judgement, not adopted.

---

## 12. Insufficiencies register (named, not filled)

1. **No source-language span data** for these words is in hand. Everything above reasons about *words*, not yet about the Scriptural evidence. The source-language field of any eventual registry will not map one-to-one onto the English concept.
2. **No grounded behavioural-science findings.** Recognised conceptual domains exist (motor cognition and grasping; psychological ownership and the endowment effect; giving-vs-taking asymmetries in behavioural economics; agency/volition; appropriation as moral act) — but these are *named domains*, not cited results. None has been verified against literature; none should be treated as evidence until it is.
3. **The universality of embodied metaphor** (§9) is unresolved and cannot be settled from the corpus.
4. **No membership criterion** yet exists for the class (§11); until one does, the class has no defined edge.

---

## 13. Where additional discovery would help

- A single source-language span report for one class member (e.g. *take* / laqach, or *walk* / halakh) would move this from word-reasoning to evidence.
- A short deliberate test of the three-mechanism split (§5) against a handful of verses would show whether the distinction survives contact with the text.
- A decision on the §11 fork is the gate: nothing downstream should be built until (A) or (B) is chosen and a membership criterion is set.

---

*Author: le Roux Cilliers. This note records a debate and one open decision; it draws no conclusions and adopts no method.*
